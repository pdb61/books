if condition:
    expression1
else:
    expression2

p = 0.6
if p <= 0.05:
    print("reject H0!")
else:
    print("don't reject H0!")

fruits = ["apple", "banana", "cherry"]
for x in sequence:
    [some commands]


#
a = [2,6,3,6]
type(a).__name__
a.count(6)
a.sort()