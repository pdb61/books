import scipy.stats as stats

sample = stats.norm.rvs(size=10)
print(f'sample: {sample}\n')
